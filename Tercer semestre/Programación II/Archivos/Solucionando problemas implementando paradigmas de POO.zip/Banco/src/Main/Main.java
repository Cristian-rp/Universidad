package Main;
// Importamos el paquete de VentanaBanco'
import Ventanas.VentanaBanco;

public class Main {


    public static void main(String[] args) {
        /*Creamos una instancia de la clase VentanaBanco 
        para poder llamar metodos como el setVisible*/
        VentanaBanco b = new VentanaBanco();
        //Hacemos visible la ventana
        b.setVisible(true);
        
    }
    
}
