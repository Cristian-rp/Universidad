package Main;

import Interfaces.Inicio;


public class Main {
    public static void main(String[] args) {
        /*Hacemos una instancia del JFrame Inicio
        para poder usar metodos como el setVisible*/
        Inicio login = new Inicio();
        //hacer visible el login
        login.setVisible(true);
    }
    
}
